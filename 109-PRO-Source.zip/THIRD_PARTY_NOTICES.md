# Third-Party Notices

109 PRO is an independent modified browser interface based on the MIT-licensed
Sylva Signer project by AntonP29. Third-party software and assets remain under
their respective licenses. This file is an attribution and compliance index,
not a replacement for those license texts.

## Bundled native and WebAssembly components

| Component | Use | License and notice location |
| --- | --- | --- |
| [zhlynn/zsign](https://github.com/zhlynn/zsign) | iOS signing core compiled to WebAssembly; upstream commit `28a6421` | MIT; `licenses/zsign-MIT.txt` |
| zlib 1.3.1 | Compression code linked into the WASM runtime | zlib License; `licenses/zlib-1.3.1-notice.txt` |
| minizip | ZIP handling linked into the WASM runtime | zlib/minizip terms; `licenses/minizip-zip-notice.txt`, `licenses/minizip-unzip-notice.txt`, and `licenses/minizip-ioapi-notice.txt` |
| [OpenSSL 3.5.7](https://www.openssl.org/) | Static cryptographic dependency linked into the WASM runtime | Apache-2.0; `licenses/openssl-3.5.7.txt` |
| [Emscripten](https://emscripten.org/) | Toolchain used to produce the prebuilt JavaScript/WASM runtime | Emscripten license terms apply to the generated runtime; see upstream build project and its notices |

The deployment package contains the prebuilt runtime in `public/wasm/`.
The complete upstream native source tree is available at
https://github.com/zhlynn/zsign and is not duplicated in this lightweight package.

## Fonts and artwork

- [Inter](https://github.com/rsms/inter) is distributed under the SIL Open Font License 1.1. The exact text is at `public/fonts/inter/OFL.txt`.
- 109 PRO logo artwork is created for this modified build.
- Apple names, iPhone, iOS, and related marks belong to Apple Inc. 109 PRO is an independent project and is not affiliated with or endorsed by Apple.

## JavaScript packages

Direct runtime and development dependencies are listed in `package.json`. Exact license texts copied for direct packages are under `licenses/npm/`. Transitive package versions and integrity hashes are recorded in `package-lock.json`; their license files are installed alongside them by `npm install`.

## Copied interface components

[Animate UI](https://animate-ui.com/) by Elliot Sutton provides animated icon wrappers, animations, and related primitives under `src/components/animate-ui/`. Animate UI's MIT plus Commons Clause license is preserved at `licenses/animate-ui.txt`, and a source notice is kept beside the components at `src/components/animate-ui/NOTICE.md`. The icon geometry is based on Lucide; Lucide and Feather-derived notices are preserved at `licenses/npm/lucide-react.txt`.

## External services

Litterbox/Catbox and Palera are optional external services, not bundled software. Their names identify the services used by the opt-in installation flow and do not imply sponsorship or endorsement. Review their current terms and privacy practices before using them.

## Maintainer note

Preserve all files under `licenses/`, `public/fonts/inter/OFL.txt`, and
`src/components/animate-ui/NOTICE.md` in source distributions.
