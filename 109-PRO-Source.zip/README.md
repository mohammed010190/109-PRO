# 109 PRO — Local iOS IPA Signer

109 PRO is a customized browser interface for local iOS IPA signing. It is based on the open-source **Sylva Signer** project by AntonP29 and its WebAssembly port of **zsign**.

## Features
- Local IPA signing in a browser Web Worker using zsign WebAssembly.
- iPhone/iPad compatibility mode intended to reduce memory pressure.
- Import IPA, P12/PFX and one or more Mobileprovision profiles.
- Inspect certificate and provisioning-profile metadata.
- Optional local certificate cache for P12, provisioning profiles and password.
- Password visibility toggle.
- Signed IPA download.
- Optional iPhone OTA installation flow with Litterbox and Catbox providers.
- Previous IPA history.

## 109 PRO changes in this build
- 109 PRO branding and black / neon-purple theme.
- Password show/hide button.
- Certificate/profile/password auto-save after the user enables local caching.
- Longer default temporary host duration (72 hours).
- Litterbox HTTP 403 handling: retry alternate Worker, then attempt direct browser upload; if still blocked, offer an explicit Catbox permanent-host alternative for eligible files.
- Clearer host failure message instead of dumping raw HTML into the UI.

## Local certificate cache warning
When enabled, P12/PFX files, provisioning profiles and the password are stored in the browser's IndexedDB on that device. The upstream cache is **not encrypted by the app**. Use only on your own trusted device and clear it when finished. Do not enable it on shared devices.

## Install / run
Requirements: Node.js 22 or later is recommended.

```bash
npm ci
npm run dev
```

Then open the local Vite URL shown in the terminal. For a production static build:

```bash
npm run build
npm run preview
```

The generated `dist/` directory can be deployed to a static HTTPS host. A public GitHub Pages site is public to anyone who knows or discovers its URL; this build does not add server-side authentication. Do not store private certificate material in the repository.

## Litterbox / Catbox limitations
- Litterbox temporary hosting may reject uploads with HTTP 403 due to host-side or network restrictions.
- 109 PRO retries the alternate Worker hostname and then attempts direct browser upload.
- If Litterbox still rejects the file, the UI can offer Catbox permanent hosting for signed IPAs within the Worker size limit. Catbox links are public and do not expire; only use this if you accept that anyone with the link can download the signed IPA.
- If neither provider accepts the file, download the signed IPA locally and use another HTTPS host you control. iOS OTA installation requires a reachable HTTPS IPA URL and manifest.
- Uploading for OTA is separate from signing. Only the signed IPA is uploaded after the user initiates installation hosting. The P12, password and provisioning profile are not uploaded by the signing flow.

## Apple signing notes
A successful local signature does not override Apple's provisioning rules. The certificate, private key, provisioning profile, Bundle ID, entitlements and device eligibility must match. Free Personal Team signing is limited and expires; broad distribution may require an Apple Developer Program membership.

## Attribution and licenses
This build retains the original MIT `LICENSE`, third-party notices, zsign license, zlib/minizip notices, OpenSSL license and dependency licenses. The prebuilt zsign WASM runtime is included; full native source is available from the upstream project. 109 PRO is an independent modified build and is not affiliated with Apple. The original upstream project is [Sylva Signer](https://github.com/AntonP29/SylvaSigner), by AntonP29. zsign is maintained at https://github.com/zhlynn/zsign.
