'use client'

import * as React from 'react'
import { motion, type Variants } from 'motion/react'

import {
  getVariants,
  useAnimateIconContext,
  IconWrapper,
  type IconProps,
} from '@/components/animate-ui/icons/icon'

type CopyProps = IconProps<keyof typeof animations>

const animations = {
  default: {
    back: {
      initial: {
        x: 0,
        y: 0,
        opacity: 1,
      },
      animate: {
        x: [-1, 1, 0],
        y: [-1, 1, 0],
        opacity: [0.7, 1, 1],
        transition: {
          duration: 0.6,
          ease: 'easeInOut',
        },
      },
    },
    front: {
      initial: {
        scale: 1,
      },
      animate: {
        scale: [1, 0.94, 1],
        transition: {
          duration: 0.6,
          ease: 'easeInOut',
        },
      },
    },
  } satisfies Record<string, Variants>,
} as const

function IconComponent({ size, ...props }: CopyProps) {
  const { controls } = useAnimateIconContext()
  const variants = getVariants(animations)

  return (
    <motion.svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <motion.rect
        width="14"
        height="14"
        x="8"
        y="8"
        rx="2"
        ry="2"
        variants={variants.front}
        initial="initial"
        animate={controls}
      />
      <motion.path
        d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"
        variants={variants.back}
        initial="initial"
        animate={controls}
      />
    </motion.svg>
  )
}

function Copy(props: CopyProps) {
  return <IconWrapper icon={IconComponent} {...props} />
}

export {
  animations,
  Copy,
  Copy as CopyIcon,
  type CopyProps,
  type CopyProps as CopyIconProps,
}
