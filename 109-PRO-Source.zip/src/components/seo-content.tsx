const signingSteps = [
  ['Choose an IPA', 'Select a local .ipa file or import an IPA from a direct URL.'],
  ['Add your certificate', 'Choose a .p12 or .pfx signing certificate and enter its password.'],
  ['Add provisioning', 'Choose one or more .mobileprovision files that cover the app and device.'],
  ['Review signing options', 'Optionally change the bundle ID or inject compatible .dylib files.'],
  ['Sign and download', 'Start local signing, keep the tab open, then download the signed IPA.'],
] as const

const faqItems = [
  {
    question: 'Does 109 PRO upload my certificate or IPA?',
    answer:
      'No. Normal signing runs locally in a browser worker, so the IPA, certificate, provisioning profile, password, dylibs, and signed output stay on this device. Only the optional installation flow uploads the already-signed IPA after you confirm it.',
  },
  {
    question: 'What is a P12 signing certificate?',
    answer:
      'A .p12 or .pfx file packages an Apple signing certificate with its private key. 109 PRO uses it locally with a provisioning profile to create a code signature for an iOS app.',
  },
  {
    question: 'Do I need Xcode or a Mac to sign an IPA?',
    answer:
      'No. 109 PRO runs zsign as WebAssembly in the browser, so signing does not require Xcode, macOS, or a remote signing server.',
  },
  {
    question: 'Which browsers work with 109 PRO?',
    answer:
      'A current Chrome or Edge browser on desktop is recommended. Safari, iPhone, iPad, Android, and other mobile browsers use an experimental compatibility path and may be slower or more memory constrained.',
  },
  {
    question: 'What is the IPA size limit?',
    answer:
      "Local signing has no fixed 109 PRO file-size limit, but it is constrained by the browser and the device's available memory. The optional temporary installation upload rejects signed IPA files larger than 1 GB.",
  },
  {
    question: 'What happens if a signing certificate is revoked?',
    answer:
      'Apple may stop trusting apps signed with a revoked certificate. Those apps can stop opening or installing even when the original signing process completed successfully.',
  },
] as const

export function PrivacySummary() {
  return (
    <section aria-labelledby="local-signing-title" className="mb-7 max-w-3xl">
      <p className="text-xs font-medium uppercase text-muted-foreground">Private by design</p>
      <h2 id="local-signing-title" className="mt-2 text-xl font-semibold md:text-2xl">
        Sign iOS IPA files locally in your browser
      </h2>
      <p className="mt-2 text-sm leading-6 text-muted-foreground md:text-base">
        109 PRO runs zsign as WebAssembly inside a dedicated browser worker. Your IPA,
        certificate, provisioning profile, password, optional dylibs, and signed output remain on
        this device during signing. Temporary installation uploads only the signed IPA after you
        explicitly confirm it.
      </p>
    </section>
  )
}

export function SigningGuideAndFaq() {
  return (
    <div className="mt-10 grid gap-10 border-t border-border pt-8 lg:grid-cols-[minmax(0,1.15fr)_minmax(19rem,0.85fr)] lg:gap-12">
      <section aria-labelledby="signing-guide-title" id="how-to-sign">
        <h2 id="signing-guide-title" className="text-lg font-semibold md:text-xl">
          How do you sign an iOS IPA file online?
        </h2>
        <p className="mt-2 text-sm leading-6 text-muted-foreground">
          109 PRO signs an iOS app package locally without Xcode or macOS. Supply the IPA, an Apple
          signing certificate, and a matching provisioning profile; review the detected app details;
          then run the WebAssembly signer and download the finished file without sending signing
          credentials to a server.
        </p>
        <ol className="mt-4 grid gap-x-6 sm:grid-cols-2">
          {signingSteps.map(([title, description], index) => (
            <li key={title} className="flex gap-2.5 border-t border-border py-3">
              <span className="flex size-6 shrink-0 items-center justify-center rounded-full bg-muted text-[11px] font-semibold">
                {index + 1}
              </span>
              <div className="min-w-0">
                <h3 className="text-[13px] font-semibold leading-5">{title}</h3>
                <p className="mt-0.5 text-xs leading-5 text-muted-foreground">{description}</p>
              </div>
            </li>
          ))}
        </ol>
      </section>

      <section aria-labelledby="faq-title" id="faq">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <h2 id="faq-title" className="text-lg font-semibold md:text-xl">
            Frequently asked questions
          </h2>
          <p className="text-xs text-muted-foreground">
            v0.1.0 <span aria-hidden>·</span>{' '}
            <time dateTime="2026-09-18">Updated Sep 18, 2026</time>
          </p>
        </div>
        <div className="mt-3 divide-y divide-border border-y border-border">
          {faqItems.map((item) => (
            <details key={item.question} className="group py-3">
              <summary className="cursor-pointer list-none pr-4 text-[13px] font-semibold leading-5 marker:hidden">
                {item.question}
              </summary>
              <p className="mt-1.5 text-xs leading-5 text-muted-foreground">
                {item.answer}
              </p>
            </details>
          ))}
        </div>
      </section>
    </div>
  )
}
