# Upstream zsign

109 PRO uses the WebAssembly runtime built from [`zhlynn/zsign`](https://github.com/zhlynn/zsign),
upstream commit `28a6421`, with browser-focused patches in the original Sylva Signer
build pipeline.

The prebuilt runtime is shipped in `public/wasm/`:
- `zsign.mjs` / `zsign.wasm`
- `zsign-mobile.mjs` / `zsign-mobile.wasm`
- `zsign-opfs.mjs` / `zsign-opfs.wasm`

The full native zsign source tree and reproducible Emscripten build toolchain are not
included in this lightweight deployment package. The upstream source remains available
at the link above. The zsign MIT license is preserved at `licenses/zsign-MIT.txt`.
zlib and minizip notices used by the compiled runtime are preserved under `licenses/`.
OpenSSL 3.5.7's Apache-2.0 license is preserved at `licenses/openssl-3.5.7.txt`.

The runtime is used locally in a dedicated browser worker. The IPA, P12/PFX, profile,
password and signed output are not uploaded during the normal signing process.
