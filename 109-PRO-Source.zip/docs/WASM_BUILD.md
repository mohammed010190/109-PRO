# WebAssembly Runtime

This lightweight 109 PRO deployment package includes the prebuilt zsign WebAssembly
runtime in `public/wasm/` for desktop, mobile compatibility, and OPFS variants.

The runtime is based on the MIT-licensed `zhlynn/zsign` project, upstream commit
`28a6421`, and includes zlib/minizip and OpenSSL components. Their notices are
preserved under `licenses/` and indexed in `THIRD_PARTY_NOTICES.md`.

The native zsign source tree and Emscripten/OpenSSL rebuild toolchain are not
included in this deployment bundle to keep manual GitHub upload small. To rebuild
or audit the native signer, use the upstream zsign source:
https://github.com/zhlynn/zsign

Normal website deployment does not rebuild WebAssembly. It runs:

```bash
npm ci
npm run build
```

The app loads the prebuilt runtime from `public/wasm/` and executes it locally in
a dedicated browser worker. The IPA, P12/PFX, provisioning profile, password and
signed output remain on the user's device during normal signing.
