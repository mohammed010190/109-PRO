# 109 PRO Deployment Checklist

109 PRO is an independent modified browser interface based on the MIT-licensed
Sylva Signer project by AntonP29 and powered by zsign WebAssembly.

## Before publishing

1. Confirm the 109 PRO icons and theme assets are included.
2. Run the verification commands:

   ```bash
   npm ci
   npm run licenses:check
   npm audit --audit-level=moderate
   npm run build
   npm run wasm:smoke
   npm run test:e2e
   ```

3. Never commit real `.p12`, `.pfx`, `.cer`, `.mobileprovision`, private-key,
   `.ipa`, or password files. The only fixture IPA is a synthetic placeholder.
4. Keep `LICENSE`, `THIRD_PARTY_NOTICES.md`, `licenses/`,
   `public/fonts/inter/OFL.txt`, and all prebuilt `public/wasm/` files.
5. Remember that GitHub Pages on a free personal account publishes a public site.
   `noindex` is not access control. Do not share the URL if you do not want others
   to use the public interface.
6. OTA installation uploads only the already-signed IPA after explicit user action.
   Litterbox links expire; Catbox links are permanent and public to anyone who has
   the link.

## License and attribution

The modified application retains the original MIT license and third-party notices.
zsign, zlib/minizip, OpenSSL, Inter, npm packages, and Animate UI retain their
respective licenses. 109 PRO is not affiliated with Apple.
